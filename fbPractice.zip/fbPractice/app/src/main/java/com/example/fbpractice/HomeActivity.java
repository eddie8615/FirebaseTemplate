package com.example.fbpractice;

import android.content.Intent;
import android.text.TextUtils;
import android.view.View;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import com.google.firebase.auth.FirebaseAuth;

public class HomeActivity extends AppCompatActivity {

    private TextView greeting;
    private Button logout;

    private FirebaseAuth auth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        greeting = (TextView) findViewById(R.id.userinfo);
        logout = findViewById(R.id.signout);

        auth = FirebaseAuth.getInstance();

        greeting.setText(TextUtils.concat("Hi, " + auth.getCurrentUser().getEmail()));


        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                auth.signOut();
                start
                startActivity(new Intent(HomeActivity.this, MainActivity.class));
            }
        });
    }
}
